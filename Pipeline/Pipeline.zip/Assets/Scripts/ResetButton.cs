using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class ResetButton : EditorWindow
{
    [MenuItem("Game/Reset")]
    static void Init()
    {
        ResetButton window = (ResetButton)EditorWindow.GetWindow(typeof(ResetButton));
        window.Show();
    }

    void OnGUI()
    {;
        if (GUILayout.Button("Reset")) PlayerPrefs.SetInt("levelNumber", 0);
    }
}